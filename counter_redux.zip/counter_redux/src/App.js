import Counter from "./component/counter";
function App() {
  return (
    <div className="App">
      <Counter />
    </div>
  );
}

export default App;
